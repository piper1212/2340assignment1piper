package com.example.android_assignment_fa_2024;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    // TODO 7: Write a unit test for ensuring correct behavior of the addTask function you implemented in TODO 2 in TaskManagerSingleton
    @Test
    public void add_task_test() {
    }
}